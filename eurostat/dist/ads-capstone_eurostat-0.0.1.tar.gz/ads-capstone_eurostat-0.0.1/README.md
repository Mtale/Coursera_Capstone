This package is part of Applied Data Science Capstone Project on Coursera.

https://www.coursera.org/learn/applied-data-science-capstone

The package is designed to download Eurostat data on German cities but it would be easy to extend it to any data under Cities and greater cities subcategory in City statistics bu Eurostat.
However, any use outside of the current scope is discouraged due to lack of testing for any other scenarios.

https://ec.europa.eu/eurostat/web/cities/data/database


